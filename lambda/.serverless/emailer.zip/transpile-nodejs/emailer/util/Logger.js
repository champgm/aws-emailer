"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var cov_2lkxilq8qm = function () {
  var path = "C:\\Users\\mismatch\\gitrepos\\aws-emailer\\lambda\\src\\emailer\\util\\Logger.js",
      hash = "dd750c492520cb4858d8b685548e38ad5cfa6401",
      global = new Function('return this')(),
      gcv = "__coverage__",
      coverageData = {
    path: "C:\\Users\\mismatch\\gitrepos\\aws-emailer\\lambda\\src\\emailer\\util\\Logger.js",
    statementMap: {
      "0": {
        start: {
          line: 4,
          column: 19
        },
        end: {
          line: 4,
          column: 57
        }
      },
      "1": {
        start: {
          line: 5,
          column: 4
        },
        end: {
          line: 5,
          column: 24
        }
      },
      "2": {
        start: {
          line: 6,
          column: 4
        },
        end: {
          line: 6,
          column: 18
        }
      }
    },
    fnMap: {
      "0": {
        name: "(anonymous_0)",
        decl: {
          start: {
            line: 3,
            column: 2
          },
          end: {
            line: 3,
            column: 3
          }
        },
        loc: {
          start: {
            line: 3,
            column: 15
          },
          end: {
            line: 7,
            column: 3
          }
        }
      }
    },
    branchMap: {},
    s: {
      "0": 0,
      "1": 0,
      "2": 0
    },
    f: {
      "0": 0
    },
    b: {},
    _coverageSchema: "332fd63041d2c1bcb487cc26dd0d5f7d97098a6c"
  },
      coverage = global[gcv] || (global[gcv] = {});

  if (coverage[path] && coverage[path].hash === hash) {
    return coverage[path];
  }

  coverageData.hash = hash;
  return coverage[path] = coverageData;
}();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Logger = function () {
  function Logger() {
    _classCallCheck(this, Logger);
  }

  _createClass(Logger, [{
    key: "log",
    value: function log(message) {
      ++cov_2lkxilq8qm.f[0];

      var output = (++cov_2lkxilq8qm.s[0], this.constructor.name + ": " + message);
      ++cov_2lkxilq8qm.s[1];
      console.log(output);
      ++cov_2lkxilq8qm.s[2];
      return output;
    }
  }]);

  return Logger;
}();

exports.default = Logger;