'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var cov_1ynqpnvf87 = function () {
  var path = 'C:\\Users\\mismatch\\gitrepos\\aws-emailer\\lambda\\src\\emailer\\retriever\\BodyRetriever.js',
      hash = '062837e329a48fe5ec8cc12a0184a5b7360a6e0e',
      global = new Function('return this')(),
      gcv = '__coverage__',
      coverageData = {
    path: 'C:\\Users\\mismatch\\gitrepos\\aws-emailer\\lambda\\src\\emailer\\retriever\\BodyRetriever.js',
    statementMap: {
      '0': {
        start: {
          line: 5,
          column: 4
        },
        end: {
          line: 5,
          column: 12
        }
      },
      '1': {
        start: {
          line: 6,
          column: 4
        },
        end: {
          line: 6,
          column: 35
        }
      },
      '2': {
        start: {
          line: 10,
          column: 26
        },
        end: {
          line: 14,
          column: 5
        }
      },
      '3': {
        start: {
          line: 16,
          column: 15
        },
        end: {
          line: 16,
          column: 17
        }
      },
      '4': {
        start: {
          line: 17,
          column: 30
        },
        end: {
          line: 22,
          column: 5
        }
      },
      '5': {
        start: {
          line: 18,
          column: 6
        },
        end: {
          line: 18,
          column: 29
        }
      },
      '6': {
        start: {
          line: 18,
          column: 17
        },
        end: {
          line: 18,
          column: 29
        }
      },
      '7': {
        start: {
          line: 20,
          column: 6
        },
        end: {
          line: 20,
          column: 58
        }
      },
      '8': {
        start: {
          line: 21,
          column: 6
        },
        end: {
          line: 21,
          column: 23
        }
      },
      '9': {
        start: {
          line: 24,
          column: 4
        },
        end: {
          line: 24,
          column: 69
        }
      },
      '10': {
        start: {
          line: 25,
          column: 4
        },
        end: {
          line: 25,
          column: 40
        }
      },
      '11': {
        start: {
          line: 26,
          column: 4
        },
        end: {
          line: 26,
          column: 16
        }
      }
    },
    fnMap: {
      '0': {
        name: '(anonymous_0)',
        decl: {
          start: {
            line: 4,
            column: 2
          },
          end: {
            line: 4,
            column: 3
          }
        },
        loc: {
          start: {
            line: 4,
            column: 27
          },
          end: {
            line: 7,
            column: 3
          }
        }
      },
      '1': {
        name: '(anonymous_1)',
        decl: {
          start: {
            line: 9,
            column: 2
          },
          end: {
            line: 9,
            column: 3
          }
        },
        loc: {
          start: {
            line: 9,
            column: 25
          },
          end: {
            line: 27,
            column: 3
          }
        }
      },
      '2': {
        name: '(anonymous_2)',
        decl: {
          start: {
            line: 17,
            column: 30
          },
          end: {
            line: 17,
            column: 31
          }
        },
        loc: {
          start: {
            line: 17,
            column: 47
          },
          end: {
            line: 22,
            column: 5
          }
        }
      }
    },
    branchMap: {
      '0': {
        loc: {
          start: {
            line: 18,
            column: 6
          },
          end: {
            line: 18,
            column: 29
          }
        },
        type: 'if',
        locations: [{
          start: {
            line: 18,
            column: 6
          },
          end: {
            line: 18,
            column: 29
          }
        }, {
          start: {
            line: 18,
            column: 6
          },
          end: {
            line: 18,
            column: 29
          }
        }]
      }
    },
    s: {
      '0': 0,
      '1': 0,
      '2': 0,
      '3': 0,
      '4': 0,
      '5': 0,
      '6': 0,
      '7': 0,
      '8': 0,
      '9': 0,
      '10': 0,
      '11': 0
    },
    f: {
      '0': 0,
      '1': 0,
      '2': 0
    },
    b: {
      '0': [0, 0]
    },
    _coverageSchema: '332fd63041d2c1bcb487cc26dd0d5f7d97098a6c'
  },
      coverage = global[gcv] || (global[gcv] = {});

  if (coverage[path] && coverage[path].hash === hash) {
    return coverage[path];
  }

  coverageData.hash = hash;
  return coverage[path] = coverageData;
}();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Logger2 = require('../util/Logger');

var _Logger3 = _interopRequireDefault(_Logger2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BodyRetriever = function (_Logger) {
  _inherits(BodyRetriever, _Logger);

  function BodyRetriever(dynamoTable) {
    _classCallCheck(this, BodyRetriever);

    ++cov_1ynqpnvf87.f[0];
    ++cov_1ynqpnvf87.s[0];

    var _this = _possibleConstructorReturn(this, (BodyRetriever.__proto__ || Object.getPrototypeOf(BodyRetriever)).call(this));

    ++cov_1ynqpnvf87.s[1];

    _this.dynamoTable = dynamoTable;
    return _this;
  }

  _createClass(BodyRetriever, [{
    key: 'retrieve',
    value: function retrieve(bodyId) {
      var _this2 = this;

      var getParameters, body, retrievalFunction;
      return regeneratorRuntime.async(function retrieve$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              ++cov_1ynqpnvf87.f[1];
              getParameters = (++cov_1ynqpnvf87.s[2], {
                Key: {
                  id: { S: bodyId }
                }
              });
              body = (++cov_1ynqpnvf87.s[3], '');
              retrievalFunction = (++cov_1ynqpnvf87.s[4], function (error, data) {
                ++cov_1ynqpnvf87.f[2];
                ++cov_1ynqpnvf87.s[5];

                if (error) {
                    ++cov_1ynqpnvf87.b[0][0];
                    ++cov_1ynqpnvf87.s[6];
                    throw error;
                  } else {
                  ++cov_1ynqpnvf87.b[0][1];
                }++cov_1ynqpnvf87.s[7];
                _this2.log('Retrieved Body: ' + JSON.stringify(data));
                ++cov_1ynqpnvf87.s[8];
                body = data.Item;
              });
              ++cov_1ynqpnvf87.s[9];
              _context.next = 7;
              return regeneratorRuntime.awrap(this.dynamoTable.getItem(getParameters, retrievalFunction));

            case 7:
              ++cov_1ynqpnvf87.s[10];

              this.log('Body retrieved: ' + body);
              ++cov_1ynqpnvf87.s[11];
              return _context.abrupt('return', body);

            case 11:
            case 'end':
              return _context.stop();
          }
        }
      }, null, this);
    }
  }]);

  return BodyRetriever;
}(_Logger3.default);

exports.default = BodyRetriever;