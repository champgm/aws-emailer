'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var cov_zcxob4thf = function () {
  var path = 'C:\\Users\\mismatch\\gitrepos\\aws-emailer\\lambda\\src\\emailer\\retriever\\SubjectRetriever.js',
      hash = '1df4db79c47e78f437da56a09cde603e9cb52aa8',
      global = new Function('return this')(),
      gcv = '__coverage__',
      coverageData = {
    path: 'C:\\Users\\mismatch\\gitrepos\\aws-emailer\\lambda\\src\\emailer\\retriever\\SubjectRetriever.js',
    statementMap: {
      '0': {
        start: {
          line: 5,
          column: 4
        },
        end: {
          line: 5,
          column: 12
        }
      },
      '1': {
        start: {
          line: 6,
          column: 4
        },
        end: {
          line: 6,
          column: 55
        }
      },
      '2': {
        start: {
          line: 10,
          column: 4
        },
        end: {
          line: 10,
          column: 57
        }
      },
      '3': {
        start: {
          line: 12,
          column: 23
        },
        end: {
          line: 13,
          column: 75
        }
      },
      '4': {
        start: {
          line: 14,
          column: 4
        },
        end: {
          line: 14,
          column: 25
        }
      },
      '5': {
        start: {
          line: 16,
          column: 22
        },
        end: {
          line: 16,
          column: 24
        }
      },
      '6': {
        start: {
          line: 17,
          column: 25
        },
        end: {
          line: 22,
          column: 5
        }
      },
      '7': {
        start: {
          line: 18,
          column: 6
        },
        end: {
          line: 18,
          column: 29
        }
      },
      '8': {
        start: {
          line: 18,
          column: 17
        },
        end: {
          line: 18,
          column: 29
        }
      },
      '9': {
        start: {
          line: 19,
          column: 6
        },
        end: {
          line: 19,
          column: 69
        }
      },
      '10': {
        start: {
          line: 20,
          column: 6
        },
        end: {
          line: 20,
          column: 39
        }
      },
      '11': {
        start: {
          line: 21,
          column: 6
        },
        end: {
          line: 21,
          column: 73
        }
      },
      '12': {
        start: {
          line: 24,
          column: 4
        },
        end: {
          line: 24,
          column: 93
        }
      },
      '13': {
        start: {
          line: 25,
          column: 4
        },
        end: {
          line: 25,
          column: 50
        }
      },
      '14': {
        start: {
          line: 26,
          column: 4
        },
        end: {
          line: 26,
          column: 27
        }
      },
      '15': {
        start: {
          line: 28,
          column: 4
        },
        end: {
          line: 28,
          column: 23
        }
      }
    },
    fnMap: {
      '0': {
        name: '(anonymous_0)',
        decl: {
          start: {
            line: 4,
            column: 2
          },
          end: {
            line: 4,
            column: 3
          }
        },
        loc: {
          start: {
            line: 4,
            column: 37
          },
          end: {
            line: 7,
            column: 3
          }
        }
      },
      '1': {
        name: '(anonymous_1)',
        decl: {
          start: {
            line: 9,
            column: 2
          },
          end: {
            line: 9,
            column: 3
          }
        },
        loc: {
          start: {
            line: 9,
            column: 28
          },
          end: {
            line: 29,
            column: 3
          }
        }
      },
      '2': {
        name: '(anonymous_2)',
        decl: {
          start: {
            line: 17,
            column: 25
          },
          end: {
            line: 17,
            column: 26
          }
        },
        loc: {
          start: {
            line: 17,
            column: 45
          },
          end: {
            line: 22,
            column: 5
          }
        }
      }
    },
    branchMap: {
      '0': {
        loc: {
          start: {
            line: 18,
            column: 6
          },
          end: {
            line: 18,
            column: 29
          }
        },
        type: 'if',
        locations: [{
          start: {
            line: 18,
            column: 6
          },
          end: {
            line: 18,
            column: 29
          }
        }, {
          start: {
            line: 18,
            column: 6
          },
          end: {
            line: 18,
            column: 29
          }
        }]
      }
    },
    s: {
      '0': 0,
      '1': 0,
      '2': 0,
      '3': 0,
      '4': 0,
      '5': 0,
      '6': 0,
      '7': 0,
      '8': 0,
      '9': 0,
      '10': 0,
      '11': 0,
      '12': 0,
      '13': 0,
      '14': 0,
      '15': 0
    },
    f: {
      '0': 0,
      '1': 0,
      '2': 0
    },
    b: {
      '0': [0, 0]
    },
    _coverageSchema: '332fd63041d2c1bcb487cc26dd0d5f7d97098a6c'
  },
      coverage = global[gcv] || (global[gcv] = {});

  if (coverage[path] && coverage[path].hash === hash) {
    return coverage[path];
  }

  coverageData.hash = hash;
  return coverage[path] = coverageData;
}();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Logger2 = require('../util/Logger');

var _Logger3 = _interopRequireDefault(_Logger2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var SubjectRetriever = function (_Logger) {
  _inherits(SubjectRetriever, _Logger);

  function SubjectRetriever(mysqlConnectionHelper) {
    _classCallCheck(this, SubjectRetriever);

    ++cov_zcxob4thf.f[0];
    ++cov_zcxob4thf.s[0];

    var _this = _possibleConstructorReturn(this, (SubjectRetriever.__proto__ || Object.getPrototypeOf(SubjectRetriever)).call(this));

    ++cov_zcxob4thf.s[1];

    _this.mysqlConnectionHelper = mysqlConnectionHelper;
    return _this;
  }

  _createClass(SubjectRetriever, [{
    key: 'retrieve',
    value: function retrieve(subjectId) {
      var _this2 = this;

      var connection, queryResult, queryHandler;
      return regeneratorRuntime.async(function retrieve$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              ++cov_zcxob4thf.f[1];
              ++cov_zcxob4thf.s[2];

              this.log('Connecting to MySQL to retireve subject.');

              connection = (++cov_zcxob4thf.s[3], this.mysqlConnectionHelper.mysqlClient.createConnection(this.mysqlConnectionHelper.sqlConnectionParameters));
              ++cov_zcxob4thf.s[4];

              connection.connect();

              queryResult = (++cov_zcxob4thf.s[5], '');
              queryHandler = (++cov_zcxob4thf.s[6], function (error, results) {
                ++cov_zcxob4thf.f[2];
                ++cov_zcxob4thf.s[7];

                if (error) {
                    ++cov_zcxob4thf.b[0][0];
                    ++cov_zcxob4thf.s[8];
                    throw error;
                  } else {
                  ++cov_zcxob4thf.b[0][1];
                }++cov_zcxob4thf.s[9];
                _this2.log('Query returned subject: ' + JSON.stringify(results));
                ++cov_zcxob4thf.s[10];
                queryResult = results[0].subject;
                ++cov_zcxob4thf.s[11];
                _this2.log('Grabbing first subject: ' + JSON.stringify(queryResult));
              });
              ++cov_zcxob4thf.s[12];


              connection.query('select subject from subjects where id = ?', [subjectId], queryHandler);
              ++cov_zcxob4thf.s[13];
              this.log('Subject retrieved: ' + queryResult);
              ++cov_zcxob4thf.s[14];
              _context.next = 15;
              return regeneratorRuntime.awrap(connection.end());

            case 15:
              ++cov_zcxob4thf.s[15];
              return _context.abrupt('return', queryResult);

            case 17:
            case 'end':
              return _context.stop();
          }
        }
      }, null, this);
    }
  }]);

  return SubjectRetriever;
}(_Logger3.default);

exports.default = SubjectRetriever;