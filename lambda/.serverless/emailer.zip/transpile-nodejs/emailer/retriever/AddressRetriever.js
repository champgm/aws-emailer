'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var cov_1np3b2xn5l = function () {
  var path = 'C:\\Users\\mismatch\\gitrepos\\aws-emailer\\lambda\\src\\emailer\\retriever\\AddressRetriever.js',
      hash = '8e2842545d9299e74a4bb11e5250fa1e9f16c4b7',
      global = new Function('return this')(),
      gcv = '__coverage__',
      coverageData = {
    path: 'C:\\Users\\mismatch\\gitrepos\\aws-emailer\\lambda\\src\\emailer\\retriever\\AddressRetriever.js',
    statementMap: {
      '0': {
        start: {
          line: 5,
          column: 4
        },
        end: {
          line: 5,
          column: 12
        }
      },
      '1': {
        start: {
          line: 6,
          column: 4
        },
        end: {
          line: 6,
          column: 55
        }
      },
      '2': {
        start: {
          line: 10,
          column: 4
        },
        end: {
          line: 10,
          column: 67
        }
      },
      '3': {
        start: {
          line: 12,
          column: 23
        },
        end: {
          line: 13,
          column: 75
        }
      },
      '4': {
        start: {
          line: 14,
          column: 4
        },
        end: {
          line: 14,
          column: 25
        }
      },
      '5': {
        start: {
          line: 16,
          column: 22
        },
        end: {
          line: 16,
          column: 24
        }
      },
      '6': {
        start: {
          line: 17,
          column: 25
        },
        end: {
          line: 22,
          column: 5
        }
      },
      '7': {
        start: {
          line: 18,
          column: 6
        },
        end: {
          line: 18,
          column: 29
        }
      },
      '8': {
        start: {
          line: 18,
          column: 17
        },
        end: {
          line: 18,
          column: 29
        }
      },
      '9': {
        start: {
          line: 19,
          column: 6
        },
        end: {
          line: 19,
          column: 71
        }
      },
      '10': {
        start: {
          line: 20,
          column: 6
        },
        end: {
          line: 20,
          column: 39
        }
      },
      '11': {
        start: {
          line: 21,
          column: 6
        },
        end: {
          line: 21,
          column: 75
        }
      },
      '12': {
        start: {
          line: 24,
          column: 4
        },
        end: {
          line: 24,
          column: 102
        }
      },
      '13': {
        start: {
          line: 25,
          column: 4
        },
        end: {
          line: 25,
          column: 50
        }
      },
      '14': {
        start: {
          line: 26,
          column: 4
        },
        end: {
          line: 26,
          column: 27
        }
      },
      '15': {
        start: {
          line: 28,
          column: 4
        },
        end: {
          line: 28,
          column: 23
        }
      }
    },
    fnMap: {
      '0': {
        name: '(anonymous_0)',
        decl: {
          start: {
            line: 4,
            column: 2
          },
          end: {
            line: 4,
            column: 3
          }
        },
        loc: {
          start: {
            line: 4,
            column: 37
          },
          end: {
            line: 7,
            column: 3
          }
        }
      },
      '1': {
        name: '(anonymous_1)',
        decl: {
          start: {
            line: 9,
            column: 2
          },
          end: {
            line: 9,
            column: 3
          }
        },
        loc: {
          start: {
            line: 9,
            column: 24
          },
          end: {
            line: 29,
            column: 3
          }
        }
      },
      '2': {
        name: '(anonymous_2)',
        decl: {
          start: {
            line: 17,
            column: 25
          },
          end: {
            line: 17,
            column: 26
          }
        },
        loc: {
          start: {
            line: 17,
            column: 45
          },
          end: {
            line: 22,
            column: 5
          }
        }
      }
    },
    branchMap: {
      '0': {
        loc: {
          start: {
            line: 18,
            column: 6
          },
          end: {
            line: 18,
            column: 29
          }
        },
        type: 'if',
        locations: [{
          start: {
            line: 18,
            column: 6
          },
          end: {
            line: 18,
            column: 29
          }
        }, {
          start: {
            line: 18,
            column: 6
          },
          end: {
            line: 18,
            column: 29
          }
        }]
      }
    },
    s: {
      '0': 0,
      '1': 0,
      '2': 0,
      '3': 0,
      '4': 0,
      '5': 0,
      '6': 0,
      '7': 0,
      '8': 0,
      '9': 0,
      '10': 0,
      '11': 0,
      '12': 0,
      '13': 0,
      '14': 0,
      '15': 0
    },
    f: {
      '0': 0,
      '1': 0,
      '2': 0
    },
    b: {
      '0': [0, 0]
    },
    _coverageSchema: '332fd63041d2c1bcb487cc26dd0d5f7d97098a6c'
  },
      coverage = global[gcv] || (global[gcv] = {});

  if (coverage[path] && coverage[path].hash === hash) {
    return coverage[path];
  }

  coverageData.hash = hash;
  return coverage[path] = coverageData;
}();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Logger2 = require('../util/Logger');

var _Logger3 = _interopRequireDefault(_Logger2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var AddressRetriever = function (_Logger) {
  _inherits(AddressRetriever, _Logger);

  function AddressRetriever(mysqlConnectionHelper) {
    _classCallCheck(this, AddressRetriever);

    ++cov_1np3b2xn5l.f[0];
    ++cov_1np3b2xn5l.s[0];

    var _this = _possibleConstructorReturn(this, (AddressRetriever.__proto__ || Object.getPrototypeOf(AddressRetriever)).call(this));

    ++cov_1np3b2xn5l.s[1];

    _this.mysqlConnectionHelper = mysqlConnectionHelper;
    return _this;
  }

  _createClass(AddressRetriever, [{
    key: 'retrieve',
    value: function retrieve(label) {
      var _this2 = this;

      var connection, queryResult, queryHandler;
      return regeneratorRuntime.async(function retrieve$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              ++cov_1np3b2xn5l.f[1];
              ++cov_1np3b2xn5l.s[2];

              this.log('Connecting to MySQL to retireve recipient address.');

              connection = (++cov_1np3b2xn5l.s[3], this.mysqlConnectionHelper.mysqlClient.createConnection(this.mysqlConnectionHelper.sqlConnectionParameters));
              ++cov_1np3b2xn5l.s[4];

              connection.connect();

              queryResult = (++cov_1np3b2xn5l.s[5], '');
              queryHandler = (++cov_1np3b2xn5l.s[6], function (error, results) {
                ++cov_1np3b2xn5l.f[2];
                ++cov_1np3b2xn5l.s[7];

                if (error) {
                    ++cov_1np3b2xn5l.b[0][0];
                    ++cov_1np3b2xn5l.s[8];
                    throw error;
                  } else {
                  ++cov_1np3b2xn5l.b[0][1];
                }++cov_1np3b2xn5l.s[9];
                _this2.log('Query returned recipient: ' + JSON.stringify(results));
                ++cov_1np3b2xn5l.s[10];
                queryResult = results[0].address;
                ++cov_1np3b2xn5l.s[11];
                _this2.log('Grabbing first recipient: ' + JSON.stringify(queryResult));
              });
              ++cov_1np3b2xn5l.s[12];
              _context.next = 11;
              return regeneratorRuntime.awrap(connection.query('select address from destinations where label = ?', [label], queryHandler));

            case 11:
              ++cov_1np3b2xn5l.s[13];

              this.log('Address retrieved: ' + queryResult);
              ++cov_1np3b2xn5l.s[14];
              _context.next = 16;
              return regeneratorRuntime.awrap(connection.end());

            case 16:
              ++cov_1np3b2xn5l.s[15];
              return _context.abrupt('return', queryResult);

            case 18:
            case 'end':
              return _context.stop();
          }
        }
      }, null, this);
    }
  }]);

  return AddressRetriever;
}(_Logger3.default);

exports.default = AddressRetriever;