'use strict';

var cov_brwjqjacu = function () {
  var path = 'C:\\Users\\mismatch\\gitrepos\\aws-emailer\\lambda\\src\\emailer\\index.js',
      hash = '413cb3f68bf5e5afcd81a900ba8279c46d0f5061',
      global = new Function('return this')(),
      gcv = '__coverage__',
      coverageData = {
    path: 'C:\\Users\\mismatch\\gitrepos\\aws-emailer\\lambda\\src\\emailer\\index.js',
    statementMap: {
      '0': {
        start: {
          line: 7,
          column: 20
        },
        end: {
          line: 7,
          column: 58
        }
      },
      '1': {
        start: {
          line: 8,
          column: 19
        },
        end: {
          line: 8,
          column: 62
        }
      },
      '2': {
        start: {
          line: 10,
          column: 0
        },
        end: {
          line: 91,
          column: 2
        }
      },
      '3': {
        start: {
          line: 11,
          column: 18
        },
        end: {
          line: 11,
          column: 46
        }
      },
      '4': {
        start: {
          line: 12,
          column: 2
        },
        end: {
          line: 12,
          column: 36
        }
      },
      '5': {
        start: {
          line: 14,
          column: 2
        },
        end: {
          line: 89,
          column: 3
        }
      },
      '6': {
        start: {
          line: 24,
          column: 25
        },
        end: {
          line: 24,
          column: 44
        }
      },
      '7': {
        start: {
          line: 27,
          column: 20
        },
        end: {
          line: 27,
          column: 40
        }
      },
      '8': {
        start: {
          line: 28,
          column: 22
        },
        end: {
          line: 28,
          column: 44
        }
      },
      '9': {
        start: {
          line: 29,
          column: 19
        },
        end: {
          line: 29,
          column: 38
        }
      },
      '10': {
        start: {
          line: 30,
          column: 18
        },
        end: {
          line: 30,
          column: 36
        }
      },
      '11': {
        start: {
          line: 31,
          column: 4
        },
        end: {
          line: 31,
          column: 42
        }
      },
      '12': {
        start: {
          line: 32,
          column: 4
        },
        end: {
          line: 32,
          column: 46
        }
      },
      '13': {
        start: {
          line: 33,
          column: 4
        },
        end: {
          line: 33,
          column: 40
        }
      },
      '14': {
        start: {
          line: 34,
          column: 4
        },
        end: {
          line: 34,
          column: 38
        }
      },
      '15': {
        start: {
          line: 37,
          column: 4
        },
        end: {
          line: 37,
          column: 53
        }
      },
      '16': {
        start: {
          line: 38,
          column: 33
        },
        end: {
          line: 38,
          column: 44
        }
      },
      '17': {
        start: {
          line: 49,
          column: 4
        },
        end: {
          line: 49,
          column: 51
        }
      },
      '18': {
        start: {
          line: 50,
          column: 36
        },
        end: {
          line: 56,
          column: 5
        }
      },
      '19': {
        start: {
          line: 64,
          column: 34
        },
        end: {
          line: 67,
          column: 5
        }
      },
      '20': {
        start: {
          line: 70,
          column: 4
        },
        end: {
          line: 70,
          column: 50
        }
      },
      '21': {
        start: {
          line: 71,
          column: 24
        },
        end: {
          line: 71,
          column: 99
        }
      },
      '22': {
        start: {
          line: 74,
          column: 4
        },
        end: {
          line: 74,
          column: 51
        }
      },
      '23': {
        start: {
          line: 75,
          column: 27
        },
        end: {
          line: 75,
          column: 71
        }
      },
      '24': {
        start: {
          line: 76,
          column: 27
        },
        end: {
          line: 76,
          column: 71
        }
      },
      '25': {
        start: {
          line: 78,
          column: 4
        },
        end: {
          line: 78,
          column: 45
        }
      },
      '26': {
        start: {
          line: 79,
          column: 29
        },
        end: {
          line: 79,
          column: 151
        }
      },
      '27': {
        start: {
          line: 81,
          column: 4
        },
        end: {
          line: 81,
          column: 38
        }
      },
      '28': {
        start: {
          line: 82,
          column: 25
        },
        end: {
          line: 82,
          column: 95
        }
      },
      '29': {
        start: {
          line: 83,
          column: 4
        },
        end: {
          line: 83,
          column: 65
        }
      },
      '30': {
        start: {
          line: 84,
          column: 4
        },
        end: {
          line: 84,
          column: 28
        }
      },
      '31': {
        start: {
          line: 86,
          column: 4
        },
        end: {
          line: 86,
          column: 47
        }
      },
      '32': {
        start: {
          line: 88,
          column: 4
        },
        end: {
          line: 88,
          column: 20
        }
      },
      '33': {
        start: {
          line: 90,
          column: 2
        },
        end: {
          line: 90,
          column: 45
        }
      }
    },
    fnMap: {
      '0': {
        name: 'handler',
        decl: {
          start: {
            line: 10,
            column: 40
          },
          end: {
            line: 10,
            column: 47
          }
        },
        loc: {
          start: {
            line: 10,
            column: 74
          },
          end: {
            line: 91,
            column: 1
          }
        }
      }
    },
    branchMap: {},
    s: {
      '0': 0,
      '1': 0,
      '2': 0,
      '3': 0,
      '4': 0,
      '5': 0,
      '6': 0,
      '7': 0,
      '8': 0,
      '9': 0,
      '10': 0,
      '11': 0,
      '12': 0,
      '13': 0,
      '14': 0,
      '15': 0,
      '16': 0,
      '17': 0,
      '18': 0,
      '19': 0,
      '20': 0,
      '21': 0,
      '22': 0,
      '23': 0,
      '24': 0,
      '25': 0,
      '26': 0,
      '27': 0,
      '28': 0,
      '29': 0,
      '30': 0,
      '31': 0,
      '32': 0,
      '33': 0
    },
    f: {
      '0': 0
    },
    b: {},
    _coverageSchema: '332fd63041d2c1bcb487cc26dd0d5f7d97098a6c'
  },
      coverage = global[gcv] || (global[gcv] = {});

  if (coverage[path] && coverage[path].hash === hash) {
    return coverage[path];
  }

  coverageData.hash = hash;
  return coverage[path] = coverageData;
}();

require('babel-polyfill');

var _awsSdk = require('aws-sdk');

var _awsSdk2 = _interopRequireDefault(_awsSdk);

var _bluebird = require('bluebird');

var _bluebird2 = _interopRequireDefault(_bluebird);

var _EmailHandler = require('./EmailHandler');

var _EmailHandler2 = _interopRequireDefault(_EmailHandler);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var mysqlClient = (++cov_brwjqjacu.s[0], _bluebird2.default.promisifyAll(require('mysql')));
var nodemailer = (++cov_brwjqjacu.s[1], _bluebird2.default.promisifyAll(require('nodemailer')));

++cov_brwjqjacu.s[2];
module.exports.handler = function handler(event, context, callback) {
  var message, inputMessage, eventId, subjectId, bodyId, label, environmentVariables, sqlConnectionParameters, mysqlConnectionHelper, dynamoTable, senderUsername, senderPassword, emailTransporter, emailHandler;
  return regeneratorRuntime.async(function handler$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          ++cov_brwjqjacu.f[0];
          message = (++cov_brwjqjacu.s[3], event.Records[0].Sns.Message);
          ++cov_brwjqjacu.s[4];

          console.log('From SNS:', message);

          ++cov_brwjqjacu.s[5];
          _context.prev = 5;

          /*
           * The input message should look like this:
           * {
           *   "eventId": UUID,
           *   "label": String,
           *   "subjectId": UUID,
           *   "bodyId": UUID
           * }
           */
          inputMessage = (++cov_brwjqjacu.s[6], JSON.parse(message));

          // Log all of the stuff from the message, to make sure it's delivered correctly.

          eventId = (++cov_brwjqjacu.s[7], inputMessage.eventId);
          subjectId = (++cov_brwjqjacu.s[8], inputMessage.subjectId);
          bodyId = (++cov_brwjqjacu.s[9], inputMessage.bodyId);
          label = (++cov_brwjqjacu.s[10], inputMessage.label);
          ++cov_brwjqjacu.s[11];

          console.log('eventId ID: ' + eventId);
          ++cov_brwjqjacu.s[12];
          console.log('subjectId ID: ' + subjectId);
          ++cov_brwjqjacu.s[13];
          console.log('bodyId ID: ' + bodyId);
          ++cov_brwjqjacu.s[14];
          console.log('label ID: ' + label);

          // Give the environment variables (from AWS) a nice name.
          ++cov_brwjqjacu.s[15];
          console.log('Grabbing environment variables...');
          environmentVariables = (++cov_brwjqjacu.s[16], process.env);

          /*
           *
           * This is what environment variable access looks like in PHP (which works)
           * $dbhost = $_SERVER['RDS_HOSTNAME'];
           * $dbport = $_SERVER['RDS_PORT'];
           * $dbname = $_SERVER['RDS_DB_NAME'];
           * $username = $_SERVER['RDS_USERNAME'];
           * $password = $_SERVER['RDS_PASSWORD'];
           */

          ++cov_brwjqjacu.s[17];
          console.log('Configuring MySQL connection...');
          sqlConnectionParameters = (++cov_brwjqjacu.s[18], {
            host: '' + environmentVariables.RDS_HOSTNAME,
            port: '' + environmentVariables.RDS_PORT,
            database: '' + environmentVariables.RDS_DB_NAME,
            user: '' + environmentVariables.RDS_USERNAME,
            password: '' + environmentVariables.RDS_PASSWORD
          });
          // const sqlConnection = mysql.createConnection(sqlConnectionParameters);
          // console.log('Connecting to MySQL database...');
          // sqlConnection.connect();

          // In my opinion, this is probably bad form. I HATE when I receieve an object and
          // don't know it's structure, but I don't want to pass two parameters when I
          // could pass just one.

          mysqlConnectionHelper = (++cov_brwjqjacu.s[19], {
            mysqlClient: mysqlClient,
            sqlConnectionParameters: sqlConnectionParameters
          });

          // Establish connection to the dynamo table where message bodies are stored.

          ++cov_brwjqjacu.s[20];
          console.log('Configuring DynamoDB client...');
          dynamoTable = (++cov_brwjqjacu.s[21], _bluebird2.default.promisifyAll(new _awsSdk2.default.DynamoDB({ params: { TableName: 'bodies' } })));

          // Grab the sender account's username and password

          ++cov_brwjqjacu.s[22];
          console.log('Grabbing sender account info...');
          senderUsername = (++cov_brwjqjacu.s[23], environmentVariables.SENDER_ACCOUNT_USERNAME);
          senderPassword = (++cov_brwjqjacu.s[24], environmentVariables.SENDER_ACCOUNT_PASSWORD);
          ++cov_brwjqjacu.s[25];


          console.log('Configuring nodemailer...');
          emailTransporter = (++cov_brwjqjacu.s[26], _bluebird2.default.promisifyAll(nodemailer.createTransport('smtps://' + senderUsername + '%40gmail.com:' + senderPassword + '@smtp.gmail.com')));
          ++cov_brwjqjacu.s[27];


          console.log('Calling Handler...');
          emailHandler = (++cov_brwjqjacu.s[28], new _EmailHandler2.default(mysqlConnectionHelper, dynamoTable, emailTransporter));
          ++cov_brwjqjacu.s[29];
          _context.next = 42;
          return regeneratorRuntime.awrap(emailHandler.handle(eventId, subjectId, bodyId, label));

        case 42:
          ++cov_brwjqjacu.s[30];

          console.log('Handled.');

          ++cov_brwjqjacu.s[31];
          console.log('Closing MySQL connection...');
          _context.next = 52;
          break;

        case 48:
          _context.prev = 48;
          _context.t0 = _context['catch'](5);
          ++cov_brwjqjacu.s[32];

          callback(_context.t0);

        case 52:
          ++cov_brwjqjacu.s[33];

          callback(null, 'Email successfully sent?');

        case 54:
        case 'end':
          return _context.stop();
      }
    }
  }, null, this, [[5, 48]]);
};