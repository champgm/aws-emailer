'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var cov_1bbxwft9b3 = function () {
  var path = 'C:\\Users\\mismatch\\gitrepos\\aws-emailer\\lambda\\src\\emailer\\sender\\MessageSender.js',
      hash = 'e183969fb4c5f2ec3217fb3fa027b679623f2636',
      global = new Function('return this')(),
      gcv = '__coverage__',
      coverageData = {
    path: 'C:\\Users\\mismatch\\gitrepos\\aws-emailer\\lambda\\src\\emailer\\sender\\MessageSender.js',
    statementMap: {
      '0': {
        start: {
          line: 5,
          column: 4
        },
        end: {
          line: 5,
          column: 12
        }
      },
      '1': {
        start: {
          line: 6,
          column: 4
        },
        end: {
          line: 6,
          column: 45
        }
      },
      '2': {
        start: {
          line: 10,
          column: 24
        },
        end: {
          line: 15,
          column: 5
        }
      },
      '3': {
        start: {
          line: 17,
          column: 4
        },
        end: {
          line: 17,
          column: 53
        }
      },
      '4': {
        start: {
          line: 18,
          column: 4
        },
        end: {
          line: 18,
          column: 40
        }
      },
      '5': {
        start: {
          line: 19,
          column: 4
        },
        end: {
          line: 19,
          column: 36
        }
      },
      '6': {
        start: {
          line: 20,
          column: 4
        },
        end: {
          line: 20,
          column: 30
        }
      },
      '7': {
        start: {
          line: 22,
          column: 4
        },
        end: {
          line: 22,
          column: 33
        }
      },
      '8': {
        start: {
          line: 23,
          column: 21
        },
        end: {
          line: 23,
          column: 23
        }
      },
      '9': {
        start: {
          line: 24,
          column: 25
        },
        end: {
          line: 27,
          column: 5
        }
      },
      '10': {
        start: {
          line: 25,
          column: 6
        },
        end: {
          line: 25,
          column: 29
        }
      },
      '11': {
        start: {
          line: 25,
          column: 17
        },
        end: {
          line: 25,
          column: 29
        }
      },
      '12': {
        start: {
          line: 26,
          column: 6
        },
        end: {
          line: 26,
          column: 33
        }
      },
      '13': {
        start: {
          line: 28,
          column: 4
        },
        end: {
          line: 28,
          column: 62
        }
      },
      '14': {
        start: {
          line: 29,
          column: 4
        },
        end: {
          line: 29,
          column: 42
        }
      },
      '15': {
        start: {
          line: 31,
          column: 4
        },
        end: {
          line: 31,
          column: 22
        }
      }
    },
    fnMap: {
      '0': {
        name: '(anonymous_0)',
        decl: {
          start: {
            line: 4,
            column: 2
          },
          end: {
            line: 4,
            column: 3
          }
        },
        loc: {
          start: {
            line: 4,
            column: 32
          },
          end: {
            line: 7,
            column: 3
          }
        }
      },
      '1': {
        name: '(anonymous_1)',
        decl: {
          start: {
            line: 9,
            column: 2
          },
          end: {
            line: 9,
            column: 3
          }
        },
        loc: {
          start: {
            line: 9,
            column: 61
          },
          end: {
            line: 32,
            column: 3
          }
        }
      },
      '2': {
        name: '(anonymous_2)',
        decl: {
          start: {
            line: 24,
            column: 25
          },
          end: {
            line: 24,
            column: 26
          }
        },
        loc: {
          start: {
            line: 24,
            column: 42
          },
          end: {
            line: 27,
            column: 5
          }
        }
      }
    },
    branchMap: {
      '0': {
        loc: {
          start: {
            line: 25,
            column: 6
          },
          end: {
            line: 25,
            column: 29
          }
        },
        type: 'if',
        locations: [{
          start: {
            line: 25,
            column: 6
          },
          end: {
            line: 25,
            column: 29
          }
        }, {
          start: {
            line: 25,
            column: 6
          },
          end: {
            line: 25,
            column: 29
          }
        }]
      }
    },
    s: {
      '0': 0,
      '1': 0,
      '2': 0,
      '3': 0,
      '4': 0,
      '5': 0,
      '6': 0,
      '7': 0,
      '8': 0,
      '9': 0,
      '10': 0,
      '11': 0,
      '12': 0,
      '13': 0,
      '14': 0,
      '15': 0
    },
    f: {
      '0': 0,
      '1': 0,
      '2': 0
    },
    b: {
      '0': [0, 0]
    },
    _coverageSchema: '332fd63041d2c1bcb487cc26dd0d5f7d97098a6c'
  },
      coverage = global[gcv] || (global[gcv] = {});

  if (coverage[path] && coverage[path].hash === hash) {
    return coverage[path];
  }

  coverageData.hash = hash;
  return coverage[path] = coverageData;
}();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Logger2 = require('../util/Logger');

var _Logger3 = _interopRequireDefault(_Logger2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var MessageSender = function (_Logger) {
  _inherits(MessageSender, _Logger);

  function MessageSender(emailTransporter) {
    _classCallCheck(this, MessageSender);

    ++cov_1bbxwft9b3.f[0];
    ++cov_1bbxwft9b3.s[0];

    var _this = _possibleConstructorReturn(this, (MessageSender.__proto__ || Object.getPrototypeOf(MessageSender)).call(this));

    ++cov_1bbxwft9b3.s[1];

    _this.emailTransporter = emailTransporter;
    return _this;
  }

  _createClass(MessageSender, [{
    key: 'send',
    value: function send(recipientAddress, senderAddress, subject, body) {
      var mailOptions, sendResult, sendFunction;
      return regeneratorRuntime.async(function send$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              ++cov_1bbxwft9b3.f[1];
              mailOptions = (++cov_1bbxwft9b3.s[2], {
                from: '"Reminder:" <' + senderAddress + '>',
                to: '' + recipientAddress,
                subject: '' + subject,
                text: '' + body
              });
              ++cov_1bbxwft9b3.s[3];


              this.log('from: "Reminder:" <' + senderAddress + '>');
              ++cov_1bbxwft9b3.s[4];
              this.log('to: ' + recipientAddress);
              ++cov_1bbxwft9b3.s[5];
              this.log('subject: ' + subject);
              ++cov_1bbxwft9b3.s[6];
              this.log('text: ' + body);

              ++cov_1bbxwft9b3.s[7];
              this.log('Sending email...');
              sendResult = (++cov_1bbxwft9b3.s[8], '');
              sendFunction = (++cov_1bbxwft9b3.s[9], function (error, info) {
                ++cov_1bbxwft9b3.f[2];
                ++cov_1bbxwft9b3.s[10];

                if (error) {
                    ++cov_1bbxwft9b3.b[0][0];
                    ++cov_1bbxwft9b3.s[11];
                    throw error;
                  } else {
                  ++cov_1bbxwft9b3.b[0][1];
                }++cov_1bbxwft9b3.s[12];
                sendResult = info.response;
              });
              ++cov_1bbxwft9b3.s[13];

              this.emailTransporter.sendMail(mailOptions, sendFunction);
              ++cov_1bbxwft9b3.s[14];
              this.log('Email sent: ' + sendResult);

              ++cov_1bbxwft9b3.s[15];
              return _context.abrupt('return', sendResult);

            case 20:
            case 'end':
              return _context.stop();
          }
        }
      }, null, this);
    }
  }]);

  return MessageSender;
}(_Logger3.default);

exports.default = MessageSender;