'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var cov_n1059vdgw = function () {
  var path = 'C:\\Users\\mismatch\\gitrepos\\aws-emailer\\lambda\\src\\emailer\\EmailHandler.js',
      hash = 'bfc54d265fe5c4c02225179fafcc27f17af8af22',
      global = new Function('return this')(),
      gcv = '__coverage__',
      coverageData = {
    path: 'C:\\Users\\mismatch\\gitrepos\\aws-emailer\\lambda\\src\\emailer\\EmailHandler.js',
    statementMap: {
      '0': {
        start: {
          line: 9,
          column: 4
        },
        end: {
          line: 9,
          column: 12
        }
      },
      '1': {
        start: {
          line: 10,
          column: 4
        },
        end: {
          line: 10,
          column: 35
        }
      },
      '2': {
        start: {
          line: 11,
          column: 4
        },
        end: {
          line: 11,
          column: 55
        }
      },
      '3': {
        start: {
          line: 12,
          column: 4
        },
        end: {
          line: 12,
          column: 45
        }
      },
      '4': {
        start: {
          line: 17,
          column: 29
        },
        end: {
          line: 17,
          column: 77
        }
      },
      '5': {
        start: {
          line: 18,
          column: 36
        },
        end: {
          line: 18,
          column: 68
        }
      },
      '6': {
        start: {
          line: 20,
          column: 29
        },
        end: {
          line: 20,
          column: 77
        }
      },
      '7': {
        start: {
          line: 21,
          column: 27
        },
        end: {
          line: 21,
          column: 63
        }
      },
      '8': {
        start: {
          line: 23,
          column: 26
        },
        end: {
          line: 23,
          column: 61
        }
      },
      '9': {
        start: {
          line: 24,
          column: 24
        },
        end: {
          line: 24,
          column: 54
        }
      },
      '10': {
        start: {
          line: 26,
          column: 29
        },
        end: {
          line: 26,
          column: 58
        }
      },
      '11': {
        start: {
          line: 27,
          column: 20
        },
        end: {
          line: 27,
          column: 40
        }
      },
      '12': {
        start: {
          line: 28,
          column: 17
        },
        end: {
          line: 28,
          column: 34
        }
      },
      '13': {
        start: {
          line: 29,
          column: 4
        },
        end: {
          line: 29,
          column: 47
        }
      },
      '14': {
        start: {
          line: 30,
          column: 4
        },
        end: {
          line: 30,
          column: 36
        }
      },
      '15': {
        start: {
          line: 31,
          column: 4
        },
        end: {
          line: 31,
          column: 30
        }
      },
      '16': {
        start: {
          line: 33,
          column: 26
        },
        end: {
          line: 33,
          column: 66
        }
      },
      '17': {
        start: {
          line: 34,
          column: 4
        },
        end: {
          line: 34,
          column: 77
        }
      },
      '18': {
        start: {
          line: 36,
          column: 27
        },
        end: {
          line: 36,
          column: 53
        }
      },
      '19': {
        start: {
          line: 37,
          column: 4
        },
        end: {
          line: 37,
          column: 34
        }
      },
      '20': {
        start: {
          line: 39,
          column: 4
        },
        end: {
          line: 39,
          column: 26
        }
      }
    },
    fnMap: {
      '0': {
        name: '(anonymous_0)',
        decl: {
          start: {
            line: 8,
            column: 2
          },
          end: {
            line: 8,
            column: 3
          }
        },
        loc: {
          start: {
            line: 8,
            column: 68
          },
          end: {
            line: 13,
            column: 3
          }
        }
      },
      '1': {
        name: '(anonymous_1)',
        decl: {
          start: {
            line: 16,
            column: 2
          },
          end: {
            line: 16,
            column: 3
          }
        },
        loc: {
          start: {
            line: 16,
            column: 65
          },
          end: {
            line: 40,
            column: 3
          }
        }
      }
    },
    branchMap: {},
    s: {
      '0': 0,
      '1': 0,
      '2': 0,
      '3': 0,
      '4': 0,
      '5': 0,
      '6': 0,
      '7': 0,
      '8': 0,
      '9': 0,
      '10': 0,
      '11': 0,
      '12': 0,
      '13': 0,
      '14': 0,
      '15': 0,
      '16': 0,
      '17': 0,
      '18': 0,
      '19': 0,
      '20': 0
    },
    f: {
      '0': 0,
      '1': 0
    },
    b: {},
    _coverageSchema: '332fd63041d2c1bcb487cc26dd0d5f7d97098a6c'
  },
      coverage = global[gcv] || (global[gcv] = {});

  if (coverage[path] && coverage[path].hash === hash) {
    return coverage[path];
  }

  coverageData.hash = hash;
  return coverage[path] = coverageData;
}();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _AddressRetriever = require('./retriever/AddressRetriever');

var _AddressRetriever2 = _interopRequireDefault(_AddressRetriever);

var _BodyRetriever = require('./retriever/BodyRetriever');

var _BodyRetriever2 = _interopRequireDefault(_BodyRetriever);

var _SubjectRetriever = require('./retriever/SubjectRetriever');

var _SubjectRetriever2 = _interopRequireDefault(_SubjectRetriever);

var _MessageSender = require('./sender/MessageSender');

var _MessageSender2 = _interopRequireDefault(_MessageSender);

var _Logger2 = require('./util/Logger');

var _Logger3 = _interopRequireDefault(_Logger2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var EmailHandler = function (_Logger) {
  _inherits(EmailHandler, _Logger);

  function EmailHandler(mysqlConnectionHelper, dynamoTable, emailTransporter) {
    _classCallCheck(this, EmailHandler);

    ++cov_n1059vdgw.f[0];
    ++cov_n1059vdgw.s[0];

    var _this = _possibleConstructorReturn(this, (EmailHandler.__proto__ || Object.getPrototypeOf(EmailHandler)).call(this));

    ++cov_n1059vdgw.s[1];

    _this.dynamoTable = dynamoTable;
    ++cov_n1059vdgw.s[2];
    _this.mysqlConnectionHelper = mysqlConnectionHelper;
    ++cov_n1059vdgw.s[3];
    _this.emailTransporter = emailTransporter;
    return _this;
  }

  _createClass(EmailHandler, [{
    key: 'handle',
    value: function handle(eventId, subjectId, bodyId, label, senderAddress) {
      var addressRetriever, recipientAddressPromise, subjectRetriever, subjectPromise, bodyRetriever, bodyPromise, recipientAddress, subject, body, messageSender, completeString;
      return regeneratorRuntime.async(function handle$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              ++cov_n1059vdgw.f[1];
              addressRetriever = (++cov_n1059vdgw.s[4], new _AddressRetriever2.default(this.mysqlConnectionHelper));
              recipientAddressPromise = (++cov_n1059vdgw.s[5], addressRetriever.retrieve(label));
              subjectRetriever = (++cov_n1059vdgw.s[6], new _SubjectRetriever2.default(this.mysqlConnectionHelper));
              subjectPromise = (++cov_n1059vdgw.s[7], subjectRetriever.retrieve(subjectId));
              bodyRetriever = (++cov_n1059vdgw.s[8], new _BodyRetriever2.default(this.dynamoTable));
              bodyPromise = (++cov_n1059vdgw.s[9], bodyRetriever.retrieve(bodyId));
              ++cov_n1059vdgw.s[10];
              _context.next = 10;
              return regeneratorRuntime.awrap(recipientAddressPromise);

            case 10:
              recipientAddress = _context.sent;
              ++cov_n1059vdgw.s[11];
              _context.next = 14;
              return regeneratorRuntime.awrap(subjectPromise);

            case 14:
              subject = _context.sent;
              ++cov_n1059vdgw.s[12];
              _context.next = 18;
              return regeneratorRuntime.awrap(bodyPromise);

            case 18:
              body = _context.sent;
              ++cov_n1059vdgw.s[13];

              this.log('Recipient: ' + recipientAddress);
              ++cov_n1059vdgw.s[14];
              this.log('Subject: ' + subject);
              ++cov_n1059vdgw.s[15];
              this.log('Body: ' + body);

              messageSender = (++cov_n1059vdgw.s[16], new _MessageSender2.default(this.emailTransporter));
              ++cov_n1059vdgw.s[17];
              _context.next = 29;
              return regeneratorRuntime.awrap(messageSender.send(recipientAddress, senderAddress, subject, body));

            case 29:
              completeString = (++cov_n1059vdgw.s[18], 'Email handling complete.');
              ++cov_n1059vdgw.s[19];

              this.log('' + completeString);

              ++cov_n1059vdgw.s[20];
              return _context.abrupt('return', completeString);

            case 34:
            case 'end':
              return _context.stop();
          }
        }
      }, null, this);
    }
  }]);

  return EmailHandler;
}(_Logger3.default);

exports.default = EmailHandler;